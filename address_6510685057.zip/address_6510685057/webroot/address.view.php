<?php
/**
 * PHPDoc comment
 *@var array $address
 */
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Address List</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/table.css">

</head>
<body>
<h1 class="page-title">ข้อมูลที่อยู่ทั้งหมด (6510685057 ญาณัชทัฬห์ คงกระจ่าง)</h1>
<a href="create.php" class="add-new">เพิ่มข้อมูลใหม่</a>
<table class = "data-table">
    <thead>
    <tr>
        <th>ID</th>
        <th>ชื่อ-นามสกุล</th>
        <th>วันเกิด</th>
        <th>อาชีพ</th>
        <th>จังหวัด</th>
        <th>เบอร์โทรศัพท์</th>
        <th>การจัดการ</th>
    </tr>
    </thead>
    <tbody>
    <?php foreach ($address as $address): ?>
        <tr>
            <td> <?= $address['id']; ?> </td>
            <td><a href="info.php?id=<?= $address['id'] ?>"><?= $address['fullname'] ?></a></td>
            <td>
                <?php
                $date = DateTime::createFromFormat('Y-m-d', $address['birthdate']);
                echo $date ? $date->format('d/m/Y') : '-';
                ?>
            </td>
            <td> <?= $address['occupation']; ?> </td>
            <td> <?= $address['province']; ?> </td>
            <td> <?= $address['phone']; ?> </td>
            <td>
                <a href="edit.php?id=<?= $address['id']; ?>" class="btn-action btn-edit">แก้ไข</a>
                <a href="delete.php?id=<?= $address['id']; ?>" class="btn-action btn-delete">ลบ</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>