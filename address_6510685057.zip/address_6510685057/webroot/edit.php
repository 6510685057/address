<?php
// update.php
$link = require('db_connect.inc.php');

$id = $_GET['id'];
$query = "SELECT * FROM address WHERE id=$id";
try {
    $result = mysqli_query($link, $query);
    $address = mysqli_fetch_assoc($result);
} catch (mysqli_sql_exception $e) {
    error_log($e);
    die("Failed to update record: " . $e->getMessage());
}
mysqli_close($link);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update Person</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kanit:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0&icon_names=arrow_back" />
    <link rel="stylesheet" href="css/create.css">
</head>
<body>
<div class="container">
    <h1>แก้ไขข้อมูลส่วนตัว</h1>
    <a href="index.php" class="arrow_back">
        <span class="material-symbols-outlined">arrow_back</span>
        กลับไปหน้าหลัก
    </a>
    <form action="index.php" method="post">
        <input type="hidden" name="update" value="<?= $address['id'] ?>">

        <div class="form-group">
            <label for="fullname">ชื่อ-นามสกุล</label>
            <input type="text" name="fullname" id="fullname" class="form-control" value="<?= $address["fullname"] ?>" required>
        </div>

        <div class="form-group">
            <label for="gender">เพศ</label>
            <input type="radio" name="gender" id="male" value="ชาย"
                <?= ($address["gender"] == "ชาย") ? 'checked' : '' ?>>
            <label for="male">ชาย</label>

            <input type="radio" name="gender" id="female" value="หญิง"
                <?= ($address["gender"] == "หญิง") ? 'checked' : '' ?>>
            <label for="female">หญิง</label>
        </div>

        <div class="form-group">
            <label for="birthdate">วัน/เดือน/ปีเกิด</label>
            <input type="text" name="birthdate" id="birthdate" class="form-control" value="<?= $address["birthdate"] ?>" required>
        </div>

        <div class="form-group">
            <label for="occupation">อาชีพ</label>
            <select name="occupation" id="occupation" class="form-control" required>
                <option value="นักศึกษา" <?= ($address["occupation"] == "นักศึกษา") ? "selected" : "" ?>>นักศึกษา</option>
                <option value="พนักงานบริษัท" <?= ($address["occupation"] == "พนักงานบริษัท") ? "selected" : "" ?>>พนักงานบริษัท</option>
                <option value="รับราชการ" <?= ($address["occupation"] == "รับราชการ") ? "selected" : "" ?>>รับราชการ</option>
                <option value="ธุรกิจส่วนตัว" <?= ($address["occupation"] == "ธุรกิจส่วนตัว") ? "selected" : "" ?>>ธุรกิจส่วนตัว</option>
            </select>
        </div>

        <div class="form-group">
            <label for="address">ที่อยู่(ตามบัตรประชาชน)</label>
            <textarea name="address" id="address" class="form-control" rows="5" required><?= $address["address"] ?></textarea>
        </div>
        <div class="form-group">
            <label for="province">จังหวัด</label>
            <select name="province" id="province" class="form-control" required>
                <option value="กระบี่" <?= ($address["province"] == "กระบี่") ? "selected" : "" ?>>กระบี่</option>
                <option value="กรุงเทพมหานคร" <?= ($address["province"] == "กรุงเทพมหานคร") ? "selected" : "" ?>>กรุงเทพมหานคร</option>
                <option value="กาญจนบุรี" <?= ($address["province"] == "กาญจนบุรี") ? "selected" : "" ?>>กาญจนบุรี</option>
                <option value="กาฬสินธุ์" <?= ($address["province"] == "กาฬสินธุ์") ? "selected" : "" ?>>กาฬสินธุ์</option>
                <option value="กำแพงเพชร" <?= ($address["province"] == "กำแพงเพชร") ? "selected" : "" ?>>กำแพงเพชร</option>
                <option value="ขอนแก่น" <?= ($address["province"] == "ขอนแก่น") ? "selected" : "" ?>>ขอนแก่น</option>
                <option value="จันทบุรี" <?= ($address["province"] == "จันทบุรี") ? "selected" : "" ?>>จันทบุรี</option>
                <option value="ฉะเชิงเทรา" <?= ($address["province"] == "ฉะเชิงเทรา") ? "selected" : "" ?>>ฉะเชิงเทรา</option>
                <option value="ชลบุรี" <?= ($address["province"] == "ชลบุรี") ? "selected" : "" ?>>ชลบุรี</option>
                <option value="ชัยนาท" <?= ($address["province"] == "ชัยนาท") ? "selected" : "" ?>>ชัยนาท</option>
                <option value="ชัยภูมิ" <?= ($address["province"] == "ชัยภูมิ") ? "selected" : "" ?>>ชัยภูมิ</option>
                <option value="ชุมพร" <?= ($address["province"] == "ชุมพร") ? "selected" : "" ?>>ชุมพร</option>
                <option value="เชียงราย" <?= ($address["province"] == "เชียงราย") ? "selected" : "" ?>>เชียงราย</option>
                <option value="เชียงใหม่" <?= ($address["province"] == "เชียงใหม่") ? "selected" : "" ?>>เชียงใหม่</option>
                <option value="ตรัง" <?= ($address["province"] == "ตรัง") ? "selected" : "" ?>>ตรัง</option>
                <option value="ตราด" <?= ($address["province"] == "ตราด") ? "selected" : "" ?>>ตราด</option>
                <option value="ตาก" <?= ($address["province"] == "ตาก") ? "selected" : "" ?>>ตาก</option>
                <option value="นครนายก" <?= ($address["province"] == "นครนายก") ? "selected" : "" ?>>นครนายก</option>
                <option value="นครปฐม" <?= ($address["province"] == "นครปฐม") ? "selected" : "" ?>>นครปฐม</option>
                <option value="นครพนม" <?= ($address["province"] == "นครพนม") ? "selected" : "" ?>>นครพนม</option>
                <option value="นครราชสีมา" <?= ($address["province"] == "นครราชสีมา") ? "selected" : "" ?>>นครราชสีมา</option>
                <option value="นครศรีธรรมราช" <?= ($address["province"] == "นครศรีธรรมราช") ? "selected" : "" ?>>นครศรีธรรมราช</option>
                <option value="นครสวรรค์" <?= ($address["province"] == "นครสวรรค์") ? "selected" : "" ?>>นครสวรรค์</option>
                <option value="นนทบุรี" <?= ($address["province"] == "นนทบุรี") ? "selected" : "" ?>>นนทบุรี</option>
                <option value="นราธิวาส" <?= ($address["province"] == "นราธิวาส") ? "selected" : "" ?>>นราธิวาส</option>
                <option value="น่าน" <?= ($address["province"] == "น่าน") ? "selected" : "" ?>>น่าน</option>
                <option value="บึงกาฬ" <?= ($address["province"] == "บึงกาฬ") ? "selected" : "" ?>>บึงกาฬ</option>
                <option value="บุรีรัมย์" <?= ($address["province"] == "บุรีรัมย์") ? "selected" : "" ?>>บุรีรัมย์</option>
                <option value="ปทุมธานี" <?= ($address["province"] == "ปทุมธานี") ? "selected" : "" ?>>ปทุมธานี</option>
                <option value="ประจวบคีรีขันธ์" <?= ($address["province"] == "ประจวบคีรีขันธ์") ? "selected" : "" ?>>ประจวบคีรีขันธ์</option>
                <option value="ปราจีนบุรี" <?= ($address["province"] == "ปราจีนบุรี") ? "selected" : "" ?>>ปราจีนบุรี</option>
                <option value="ปัตตานี" <?= ($address["province"] == "ปัตตานี") ? "selected" : "" ?>>ปัตตานี</option>
                <option value="พระนครศรีอยุธยา" <?= ($address["province"] == "พระนครศรีอยุธยา") ? "selected" : "" ?>>พระนครศรีอยุธยา</option>
                <option value="พะเยา" <?= ($address["province"] == "พะเยา") ? "selected" : "" ?>>พะเยา</option>
                <option value="พังงา" <?= ($address["province"] == "พังงา") ? "selected" : "" ?>>พังงา</option>
                <option value="พัทลุง" <?= ($address["province"] == "พัทลุง") ? "selected" : "" ?>>พัทลุง</option>
                <option value="พิจิตร" <?= ($address["province"] == "พิจิตร") ? "selected" : "" ?>>พิจิตร</option>
                <option value="พิษณุโลก" <?= ($address["province"] == "พิษณุโลก") ? "selected" : "" ?>>พิษณุโลก</option>
                <option value="เพชรบุรี" <?= ($address["province"] == "เพชรบุรี") ? "selected" : "" ?>>เพชรบุรี</option>
                <option value="เพชรบูรณ์" <?= ($address["province"] == "เพชรบูรณ์") ? "selected" : "" ?>>เพชรบูรณ์</option>
                <option value="แพร่" <?= ($address["province"] == "แพร่") ? "selected" : "" ?>>แพร่</option>
                <option value="ภูเก็ต" <?= ($address["province"] == "ภูเก็ต") ? "selected" : "" ?>>ภูเก็ต</option>
                <option value="มหาสารคาม" <?= ($address["province"] == "มหาสารคาม") ? "selected" : "" ?>>มหาสารคาม</option>
                <option value="มุกดาหาร" <?= ($address["province"] == "มุกดาหาร") ? "selected" : "" ?>>มุกดาหาร</option>
                <option value="แม่ฮ่องสอน" <?= ($address["province"] == "แม่ฮ่องสอน") ? "selected" : "" ?>>แม่ฮ่องสอน</option>
                <option value="ยะลา" <?= ($address["province"] == "ยะลา") ? "selected" : "" ?>>ยะลา</option>
                <option value="ยโสธร" <?= ($address["province"] == "ยโสธร") ? "selected" : "" ?>>ยโสธร</option>
                <option value="ร้อยเอ็ด" <?= ($address["province"] == "ร้อยเอ็ด") ? "selected" : "" ?>>ร้อยเอ็ด</option>
                <option value="ระนอง" <?= ($address["province"] == "ระนอง") ? "selected" : "" ?>>ระนอง</option>
                <option value="ระยอง" <?= ($address["province"] == "ระยอง") ? "selected" : "" ?>>ระยอง</option>
                <option value="ราชบุรี" <?= ($address["province"] == "ราชบุรี") ? "selected" : "" ?>>ราชบุรี</option>
                <option value="ลพบุรี" <?= ($address["province"] == "ลพบุรี") ? "selected" : "" ?>>ลพบุรี</option>
                <option value="ลำปาง" <?= ($address["province"] == "ลำปาง") ? "selected" : "" ?>>ลำปาง</option>
                <option value="ลำพูน" <?= ($address["province"] == "ลำพูน") ? "selected" : "" ?>>ลำพูน</option>
                <option value="เลย" <?= ($address["province"] == "เลย") ? "selected" : "" ?>>เลย</option>
                <option value="ศรีสะเกษ" <?= ($address["province"] == "ศรีสะเกษ") ? "selected" : "" ?>>ศรีสะเกษ</option>
                <option value="สกลนคร" <?= ($address["province"] == "สกลนคร") ? "selected" : "" ?>>สกลนคร</option>
                <option value="สงขลา" <?= ($address["province"] == "สงขลา") ? "selected" : "" ?>>สงขลา</option>
                <option value="สตูล" <?= ($address["province"] == "สตูล") ? "selected" : "" ?>>สตูล</option>
                <option value="สมุทรปราการ" <?= ($address["province"] == "สมุทรปราการ") ? "selected" : "" ?>>สมุทรปราการ</option>
                <option value="สมุทรสงคราม" <?= ($address["province"] == "สมุทรสงคราม") ? "selected" : "" ?>>สมุทรสงคราม</option>
                <option value="สมุทรสาคร" <?= ($address["province"] == "สมุทรสาคร") ? "selected" : "" ?>>สมุทรสาคร</option>
                <option value="สระแก้ว" <?= ($address["province"] == "สระแก้ว") ? "selected" : "" ?>>สระแก้ว</option>
                <option value="สระบุรี" <?= ($address["province"] == "สระบุรี") ? "selected" : "" ?>>สระบุรี</option>
                <option value="สิงห์บุรี" <?= ($address["province"] == "สิงห์บุรี") ? "selected" : "" ?>>สิงห์บุรี</option>
                <option value="สุโขทัย" <?= ($address["province"] == "สุโขทัย") ? "selected" : "" ?>>สุโขทัย</option>
                <option value="สุพรรณบุรี" <?= ($address["province"] == "สุพรรณบุรี") ? "selected" : "" ?>>สุพรรณบุรี</option>
                <option value="สุราษฎร์ธานี" <?= ($address["province"] == "สุราษฎร์ธานี") ? "selected" : "" ?>>สุราษฎร์ธานี</option>
                <option value="สุรินทร์" <?= ($address["province"] == "สุรินทร์") ? "selected" : "" ?>>สุรินทร์</option>
                <option value="หนองคาย" <?= ($address["province"] == "หนองคาย") ? "selected" : "" ?>>หนองคาย</option>
                <option value="หนองบัวลำภู" <?= ($address["province"] == "หนองบัวลำภู") ? "selected" : "" ?>>หนองบัวลำภู</option>
                <option value="อ่างทอง" <?= ($address["province"] == "อ่างทอง") ? "selected" : "" ?>>อ่างทอง</option>
                <option value="อำนาจเจริญ" <?= ($address["province"] == "อำนาจเจริญ") ? "selected" : "" ?>>อำนาจเจริญ</option>
                <option value="อุดรธานี" <?= ($address["province"] == "อุดรธานี") ? "selected" : "" ?>>อุดรธานี</option>
                <option value="อุตรดิตถ์" <?= ($address["province"] == "อุตรดิตถ์") ? "selected" : "" ?>>อุตรดิตถ์</option>
                <option value="อุทัยธานี" <?= ($address["province"] == "อุทัยธานี") ? "selected" : "" ?>>อุทัยธานี</option>
                <option value="อุบลราชธานี" <?= ($address["province"] == "อุบลราชธานี") ? "selected" : "" ?>>อุบลราชธานี</option>
            </select>

        </div>
        <div class="form-group">
            <label for="phone">โทร</label>
            <input type="text" name="phone" id="phone" class="form-control" value="<?= $address["phone"] ?>" required>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn btn-submit">บันทึกการแก้ไข</button>
            <a href="index.php"  class="btn btn-reset">ยกเลิก</a>
        </div>
    </form>
</div>
</body>
</html>

